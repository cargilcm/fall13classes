package jadvisor.advisorui;

import jadvisor.scheduler.Course;
import jadvisor.scheduler.StudentClass;
import jadvisor.scheduler.TimeOfDay;
import jadvisor.school.UNC;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.StringTokenizer;

public class Test {

	private static TimeOfDay[] times;
/*
	public static void main(String[] args) {
		String s = "<a name = COM630    ></a><a name = COM630+001 href=\"/web/20030801235716/http://www2.acs.ncsu.edu/reg_records/crs_cat/COM.html#COM630\"     >COM  630  001</a> <b> INDEPENDENT STUDY  </b> <font size=2>call no:</font><b>231500  </b><font size=2>status:</font><b>restricted  </b><font size=2>cr:</font><b>var </b><font size=2> total class size:</font><b>20   </b><font size=2>open seats avail:</font><b>0    </b>"
				+ "<font size=2>days:</font><b>ARRANG  </b><font size=2>time:</font><b>            </b><font size=2>instr:</font><b>W JORDAN         </b><font size=2>bldg:<a href=\"/web/20030801235716/http://www2.ncsu.edu/ncsu/facilities/buildings/winston.html\"        >WINSTON</a>      rm:</font><b>00201   </b><font size=2>rstr seats avail:</font><b>19   </b><font size=2>wait list avail:</font><b>N/A  </";
		new Test(s);
	}
*/
	public Test(String s) {
		System.out.println(parseClassData(s, s, s));
	}

	private StudentClass parseClassData(String s1, String s3, String s4) {
		//System.out.println(s1);
		int index = s3.indexOf("</A>");
		if (index >= 0)
			s3 = new String(s3.substring(0, index)
					+ s3.substring(index + 4, s3.length()));

		String[] tokens = new String[14];
		tokens[0] = s1.substring(6, 15); // 0 - DEPT
		tokens[1] = s1.substring(16, 27); // 1 - NUM
		tokens[2] = s1.substring(26, 53); // 2 - NAME
		tokens[3] = s1.substring(54, 57); // 3 - LEC/REC/LAB
		tokens[4] = s1.substring(61, 66); // 4 - CREDIT

		tokens[5] = s3.substring(0, 8); // 5 - NOTE
		tokens[6] = s3.substring(9, 14); // 6 - CALL NO
		tokens[7] = s3.substring(15, 19); // 7 - SEC
		// tokens[8] = s3.substring(20, 28); //8 - DAYS
		tokens[8] = "W";
		// tokens[9] = s3.substring(29, 44); //9 - TIME
		tokens[9] = "02:50 PM  -03:30 AM";
		tokens[10] = s3.substring(45, 60); // 10 - INSTRUCTOR
		tokens[11] = s3.substring(61, 63); // 11 - BUILDING
		tokens[12] = s3.substring(66, 70); // 12 - ROOM NO.
		tokens[13] = s3.substring(71, 78); // 13 - STATUS

		for (int i = 0; i < tokens.length; i++)
			tokens[i] = tokens[i].trim();

		boolean[] days = new boolean[5];
		String[] daysAbbrev = new String[] { "M", "T", "W", "R", "F" };
		Arrays.fill(days, false);
		for (int i = 0; i < days.length; i++)
			if (tokens[8].indexOf(daysAbbrev[i]) != -1)
				days[i] = true;

		TimeOfDay[] times = parseTime(tokens[9]);

		int credit;
		if (tokens[4].indexOf("*VAR*") >= 0)
			credit = 0;
		else
			credit = (int) Double.parseDouble(tokens[4]);

		StudentClass result = new StudentClass(
				new Course(tokens[0], tokens[1]), tokens[7], days, times[0],
				times[1], 0, credit);

		List classInfo = new ArrayList();
		// classInfo.add(tokens[10]); //10 - INSTRUCTOR
		// classInfo.add(tokens[11]); //11 - BUILDING
		result.setInfo(classInfo);
		System.out.println("result:"+result);
		return result;
	}

	private TimeOfDay[] parseTime(String s) {
		if (s.equals("*TBA*"))
			return new TimeOfDay[] { new TimeOfDay(12, 00),
					new TimeOfDay(12, 00) };
		TimeOfDay[] result = new TimeOfDay[2];
		String[] s1 = new String[2];
		StringTokenizer t = new StringTokenizer(s, "-");
		for (int i = 0; t.hasMoreTokens(); i++)
			s1[i] = t.nextToken();

		int starth = Integer.parseInt(s1[0].substring(0, 2));
		int startm = Integer.parseInt(s1[0].substring(3, 5));
		int startAMPM;
		if (s1[0].substring(5, 6).equals("A"))
			startAMPM = TimeOfDay.AM;
		else
			startAMPM = TimeOfDay.PM;

		// System.out.println(s1[0]);
		// System.out.println(s1[1]);
		// System.out.println();
		// System.out.println(starth);
		// System.out.println(startm);

		int endh = Integer.parseInt(s1[1].substring(0, 2));
		int endm = Integer.parseInt(s1[1].substring(3, 5));
		int endAMPM;
		if (s1[1].substring(5, 6).equals("A"))
			endAMPM = TimeOfDay.AM;
		else
			endAMPM = TimeOfDay.PM;

		result[0] = new TimeOfDay(starth, startm, startAMPM);
		result[1] = new TimeOfDay(endh, endm, endAMPM);
		times = result;
		return result;
	}
}
