package jadvisor.advisorui;

public class TestNCSUMethods {

}
