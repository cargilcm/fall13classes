import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * a class to take raw-XML file object instances and be able to return
 * a BibTex-formatted version of the Reference regardless of the type
 * format the reference was originally saved in.
 * @author Chris Cargile
 * @since 10/10/2013
 */
public class FormatAdapter {

	ArrayList<AdaptationLaborer> adaptees = new ArrayList<AdaptationLaborer>(); 
	ArrayList<String> adaptations = new ArrayList<String>();
	String msoNS = "http://schemas.openxmlformats.org/officeDocument/2006/bibliography";
	private ArrayList<NodeItem> nodes;
	boolean mso=false;
		
	/**
	 * add an AdaptationLaborer to the set of known AdaptationLaborer(s)
	 * so its adaptation can be broadcast to the main program.
	 * @param adaptee
	 */
	public void addAdapter(AdaptationLaborer adaptee){
		adaptees.add(adaptee);
	}
	/**
	 * adapts all instances of available AdaptationLaborers in the FormatAdapter
	 * so their adaptation can be retrieved by getAdaptation()
	 * @return
	 */
	public void adaptAll(){
		for(AdaptationLaborer adaptee:adaptees)
			adaptations.add(adaptee.map());
	}
	/**
	 * get the Target-friendly representation of the adaptee's bibliographic
	 * entry.
	 * @param i index at which the AdaptationWorker is added into the FormatAdapter's
	 * set so its association
	 * @return bibTex-formatted entry adapted from the <AdaptationLaborer> adaptee style
	 */
	public String getAdaptation(int i){
		try{
		if(adaptations==null || adaptations.get(i)==null)
			throw new Exception("error getting the specified adaptation");
		}
		catch(Exception e){
			System.out.println(e);
		}
		return adaptations.get(i);
	}
	
}
