import java.io.File;
import java.util.ArrayList;



public class MSOtoBIBconverter implements AdaptationLaborer {
	//fields
	ArrayList<NodeItem>nodes;
	String msoNS = "http://schemas.openxmlformats.org/officeDocument/2006/bibliography";
	
	
	public MSOtoBIBconverter(File f){
		if(f==null)
			System.err.println("file in MSOconverter null");
		XmlDOMListConverter converter = new XmlDOMListConverter(f);//this.getFileChoosen());
		converter.init();
		nodes = converter.getNodes();
	}
	/**
	 * takes a MSO bibliography in a list:{name,value}'s and returns a string
	 * representation of the bibliography in BibTex format. 
	 * @param value
	 * @return
	 */
	private String mapMsoToTex(){
		String result = "@INPROCEEDINGS{,\n";
		for(NodeItem s:nodes){
			result+=mapMSOfieldToTex(s);
		}
		return result +="}";
	}
	
	/**
	 * 
	 * @param field
	 * @return
	 */
	private String mapMSOfieldToTex(NodeItem field){
		
		String part1=field.getNodeType();
		String part2=field.getNodeValue();
			
		switch(part1){
		case("b:Source"):
			return "";
		case("b:ConferenceName"):
			if(field.toString().contains(":"))
				return "SourceType = {" + part2 +"},\n";//"author" not valid BibTex descriptor
			return "";
		case("b:Author"):
			if(field.toString().contains(":"))
				return "author = {" + part2 +"},\n";//"author" not valid BibTex descriptor
			return "";
		case("b:Title"):
			if(field.toString().contains(":"))
				return "title = {" + part2 +"},\n";//"author" not valid BibTex descriptor
			return "";
		case("b:Last"):
			part1="title = {";
			return part1+part2+"},";//"author" not valid BibTex descriptor
			
		default:
			return part1+part2+"},";
		}
		/*
		@INPROCEEDINGS{Test,
			  author = {Test},
			  title = {Test},
			  booktitle = {Test},
			  year = {Test},
			  editor = {Test},
			  volume = {Test},
			  number = {Test},
			  series = {Test},
			  pages = {Test},
			  address = {Test},
			  month = {Test},
			  organization = {Test},
			  publisher = {Test},
			  note = {Test},
			  abstract = {Test},
			  comment = {Test},
			  crossref = {Test},
			  doi = {Test},
			  keywords = {Test},
			  owner = {chris},
			  review = {Test},
			  timestamp = {2013.10.04},
			  url = {Test}
			  
			  
			  
@inproceedings{nuseibeh_requirements_2000,
	address = {New York, {NY}, {USA}},
	series = {{ICSE} '00},
	title = {Requirements engineering: a roadmap},
	isbn = {1-58113-253-0},
	url = {http://doi.acm.org/10.1145/336512.336523},
	doi = {10.1145/336512.336523},
	booktitle = {Proceedings of the Conference on The Future of Software Engineering},
	publisher = {{ACM}},
	author = {Nuseibeh, Bashar and Easterbrook, Steve},
	year = {2000},
	pages = {35�46}
}
			  <b:Source>
				<b:Tag>Nus</b:Tag>
				<b:SourceType>ConferenceProceedings</b:SourceType>
				<b:Guid>{C0D7B815-723C-4571-B25F-A535C693A626}</b:Guid>
				<b:Title>Requirements engineering: a roadmap</b:Title>
				<b:ConferenceName>Proceedings of the Conference on The Future of Software Engineering</b:ConferenceName>
				<b:Author>
					<b:Author>
					<b:NameList>
					<b:Person>
					<b:Last>Nuseibeh</b:Last>
					<b:First>Bashar</b:First></b:Person>
					<b:Person>
					<b:Last>Easterbrook</b:Last>
					<b:First>Steve</b:First>
					</b:Person>
					</b:NameList>
					</b:Author>
				</b:Author>
				</b:Source>
		
			<b:Tag>Test</b:Tag>
			<b:SourceType>ConferenceProceedings</b:SourceType>
			<b:Guid>{DD9CBFD3-D643-41B0-911A-929E349FF3C8}</b:Guid>
			<b:Title>Test</b:Title>
			<b:Year>Test</b:Year>
			<b:ConferenceName>Test</b:ConferenceName>
			<b:City>Test</b:City>
			<b:Last>Test</b:Last>
			</b:Person>
			</b:NameList>
			</b:Author>
			<b:Last>Test</b:Last>
			</b:Person>
			</b:NameList>
			</b:Editor>
			</b:Author>
			<b:Pages>Test</b:Pages>
			<b:Publisher>Test</b:Publisher>
			<b:Volume>Test</b:Volume>
			<b:ShortTitle>Test</b:ShortTitle>
			<b:StandardNumber>Test</b:StandardNumber>
			<b:Comments>Test</b:Comments>
			<b:Medium>Test</b:Medium>
			<b:YearAccessed>Test</b:YearAccessed>
			<b:MonthAccessed>Test</b:MonthAccessed>
			<b:DayAccessed>Test</b:DayAccessed>
			<b:URL>Test</b:URL>
			<b:DOI>Test</b:DOI>
			
			*/
		}
	@Override
	public MSOtoBIBconverter create(File f) {
		return new MSOtoBIBconverter(f);
	}
	@Override
	public String getUniqueID() {
		return msoNS;
	}
	@Override
	public String map() {
		return mapMsoToTex();
	}
	@Override
	public String mapField(NodeItem nodeItem) {
		return mapMSOfieldToTex(nodeItem);
	}
}
