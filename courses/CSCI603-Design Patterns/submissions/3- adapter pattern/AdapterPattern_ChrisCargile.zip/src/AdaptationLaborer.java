import java.io.File;
import java.util.ArrayList;


public interface AdaptationLaborer {
	String name = "";
	String uniqueDescriptor="";
	String mapping="";
	String nodeMapping="";
//	XmlDOMListConverter converter;//this.getFileChoosen());
//	ArrayList<NodeItem>nodes=;
	
	
	public AdaptationLaborer create(File f);
	public String getUniqueID();
	public String map();
	public String mapField(NodeItem nodeItem);
	
	
}
