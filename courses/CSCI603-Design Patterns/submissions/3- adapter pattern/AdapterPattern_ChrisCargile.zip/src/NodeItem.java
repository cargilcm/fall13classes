/**
 * internal object representing a {nodeType,#text-nodeValue} pair
 * 
 * @author Chris Cargile
 * 
 */
public class NodeItem {
	String nodeType = "";
	String v = "";

	public NodeItem(String node) {
		nodeType = node;
	}

	public NodeItem(String node, String value) {
		nodeType = node;
		v = value;
	}

	public String getNodeType() {
		return nodeType;
	}
	public String getNodeValue(){
		return v;
	}

	public String toString() {
		if (!v.equals("") && !nodeType.equals(""))
			return nodeType + ": " + v;
		if (v.equals("") && nodeType != "")
			return nodeType;
		return "nodeitem returned null";
	}
}
