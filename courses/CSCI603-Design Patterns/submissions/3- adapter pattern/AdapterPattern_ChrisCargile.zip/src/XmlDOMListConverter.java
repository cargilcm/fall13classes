import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * a class that accepts a raw XML file object and can produce an ArrayList representation
 * of the nodes/subnodes from the XML nesting.  if the node was a node containing text,
 * the node will be represented as node:value, else it will show as simply 'node'
 * @author chris
 *
 */
public class XmlDOMListConverter {
		File f;
		String xmlSource = "";
		Document document;
		DocumentBuilder documentBuilder;
		NodeList nodeList;
		ArrayList<NodeItem> nodes= new ArrayList<NodeItem>();
		int counter = 0;
		
		//constructor
		public XmlDOMListConverter(File file) {
			if(file!=null)
				f = file;
			else
				System.err.println("file in XMLDOMListConverter constructor null");
			try {
				DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
				documentBuilderFactory.setNamespaceAware(true);
				documentBuilder = documentBuilderFactory.newDocumentBuilder();
			} catch (ParserConfigurationException e) {
				System.out.println("Error: ParserConfigurationException.");
			}
		}

		/**
		 * initiate an adaptation by parsing the MSO XML citation source
		 * so it can be adapted later into the appropriate style
		 */
		public void init(){
			if(f!=null){
				document = parseXMLfile(f);
				nodeList = (NodeList)document.getFirstChild();
				doSomethingWithAll(nodeList);
			}
			else{
				System.out.println("you must have selected a file previously");
			}
		}
		
		/**
		 * recursively visit each node and add to the <ArrayList>nodes,
		 * in transit
		 * @param nodelist node from which to begin descending
		 */
		void doSomethingWithAll(NodeList nodelist)
		{
			for(int i=0; i<nodelist.getLength(); i++){
			     Node childNode = nodelist.item(i);
			     if(childNode.getNodeType()!=Node.TEXT_NODE){
			    	 NodeItem n=new NodeItem(childNode.getNodeName()+"");
			    	 nodes.add(n);
			     }
			     else{
			    	 if(nodes.size()==0)
			    		 continue;
			    	 else{
			    		 String oldNode = nodes.get(nodes.size()-1).getNodeType();
				    	 NodeItem n=new NodeItem(oldNode,childNode.getNodeValue());
				    	 nodes.set(nodes.size()-1, n);
				    	 }
			    	 }
			     if(childNode.hasChildNodes()){
			    	 doSomethingWithAll(childNode.getChildNodes());
			    	 }
		    }
		}
		/**
		 * Get the result of parsing the XML as a list of all the node-types, and
		 * if the nodeName==#text, the nodeName will have a value associated, otherwise
		 * the associated value will be ==null.
		 * @return ArrayList of all the node-value 2ples from the parsed XML1 
		 */
		public ArrayList<NodeItem> getNodes(){
			/*
			ArrayList<String> list = new ArrayList<String>(nodes.size());
			for(NodeItem item:nodes)
				list.add(item.toString());
			return list;*/
			return nodes;
		}
		
		/**
		 * booster to translate a raw XML file into Java's internal document
		 * representation
		 * @param file raw XML
		 * @return Document whose nodes are those of the XML file
		 */
		public Document parseXMLfile(File file) {
			try {
				document = documentBuilder.parse(file);
				document.normalize();
				return document;
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (SAXException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return null;
		}
}
