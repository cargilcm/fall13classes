package com.apple.cocoa.foundation;

public interface NSKeyValueCoding
{
}
