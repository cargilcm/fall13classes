package com.apple.cocoa.foundation;

public interface NSCoding
{
}
