package com.apple.cocoa.application;

public interface NSValidatedUserInterfaceItem
{
}
